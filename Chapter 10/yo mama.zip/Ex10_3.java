//Author Cooter Gale

class Ex10_3 {
	public static void main(String[] args) {
		MyInt i = new MyInt(7);
		System.out.println("Testing isEven functions:");
		System.out.println(MyInt.isEven(i));
		System.out.println(MyInt.isEven(12));
		System.out.println(i.isEven());
		
		System.out.println("Testing isOdd functions:");
		System.out.println(MyInt.isOdd(i));
		System.out.println(MyInt.isOdd(12));
		System.out.println(i.isOdd());
		
		System.out.println("Testing isPrime functions:");
		System.out.println(MyInt.isPrime(i));
		System.out.println(MyInt.isPrime(12));
		System.out.println(i.isPrime());
		
		System.out.println("Testing equals functions:");
		System.out.println(i.equals(7));
		System.out.println(i.equals(8));
		
		char[] array = new char[5];
		int index = 0;
		for (char c = 'a'; c <= 'e'; c++) {
			array[index++] = c;
		}
		
		System.out.println("Testing parse functions:");
		System.out.println(i.parseInt("hi"));
		System.out.println(i.parseInt(array));
	}
}