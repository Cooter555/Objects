/*
Author: Cooter Gale
Date: 2/4/19

object class
static and non static methods

_______________________________
	MyInt
_______________________________
value int
_______________________________
MyInteger(value: int)
isEven(value: int): boolean *static*
isEven(value: MyInteger) : boolean *static*
is Even(): boolean
is Odd(value: int): boolean *static*
is Odd(value: MyInteger): boolean *static*
is Odd(): boolean
is Prime(value: int): boolean *static*
is Prime(value: MyInteger): boolean *static*
is Prime(): boolean 
equals(value: int): boolean
equals(value: MyInteger): boolean
parseInt(s: String): int *static*
parseInt(c: char[]): int *static*
________________________________
*/
class MyInt {
	int value;
	
	public MyInt(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return this.value;
	}
	
	public static boolean isEven(int val) {
		if (val % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	public static boolean isEven(MyInt val){
		return (val.getValue() % 2 == 0);
	}
	
	public boolean isEven() {
		return isEven(this.value);
	}
	
	public static boolean isOdd(int val) {
		if (val % 2 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isOdd(MyInt val){
		return (val.getValue() % 2 == 1);
	}
		
	public boolean isOdd() {
		return isOdd(this.value);
	}
	
	public static boolean isPrime(int val) {
		if (val == 1 || val == 2) {
			return true;
		}
		for (int i = 2; i <= val/2; i++) {
			if (val % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean isPrime(MyInt val) {
		return isPrime(val.getValue());
	}
	public boolean isPrime() {
		return isPrime(this.value);
	}
	
	public boolean equals(int val) {
		return (val == this.value);
	}
	public boolean equals(MyInt val) {
		return (val.getValue() == this.value);
	}
	public static int parseInt(char[] numbers) {
		String s = new String(numbers);
		return parseInt(s);
	}
	public static int parseInt(String s) {
		int result = 0;
		for (int i = 0; i < s.length(); i++) {
			result = result * 10 + (s.charAt(i) - '0');
		}
		return result;
	}
}