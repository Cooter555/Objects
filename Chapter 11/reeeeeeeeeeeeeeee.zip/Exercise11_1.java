/*
author: Cooter Gale
Date: 2/11/19
*/
import java.util.Scanner;

class Exercise11_1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double s1 = 0;
		double s2 = 0;
		double s3 = 0;
		String color = "";
		boolean fill = false;
		
		System.out.println("Enter length of side 1: ");
		s1 = input.nextDouble();
		System.out.println("Enter length of side 2: ");
		s2 = input.nextDouble();
		System.out.println("Enter length of side 3: ");
		s3 = input.nextDouble();
		System.out.println("Enter color: ");
		input.nextLine();
		color = input.nextLine().trim();
		System.out.println("Is the shape filled? (true/false) ");
		fill = input.nextBoolean();
		
		Triangle t1 = new Triangle(s1, s2, s3);
		t1.setColor(color);
		t1.setFilled(fill);
		
		System.out.println(t1.toString());
	}
}