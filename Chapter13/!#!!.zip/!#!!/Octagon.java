/*
Author: Cooter Gale
Date: 3/20/2019
*/
public class Octagon extends AbstractGeometricObject implements Cloneable, Comparable<Octagon> {
	private double sideLength;
	
	public Octagon() {
		super();
		this.sideLength = 1;
	}
	public Octagon(double l) {
		super();
		this.sideLength = l;
	}
	public Octagon(String c, boolean f,double l) {
		super(c, f);
		this.sideLength = l;
	}
	@Override
	public double getArea() {
		return ((2 + 4 / Math.sqrt(2)) * sideLength * sideLength);
	}
	@Override
	public double getPerimeter() {
		return sideLength * 8;
	}
	@Override
	public Object clone() {
		//return super.clone();
		try{
		Octagon copy = (Octagon)super.clone();
		copy.sideLength = this.sideLength;
		return copy;
		}
		catch(CloneNotSupportedException ex) {
			return null;
		}
		
	}
	
	@Override
	public int compareTo(Octagon o) {
		if (this.sideLength > o.sideLength) {
			return 1;
		}
		else if (this.sideLength == o.sideLength) {
			return 0;
		}
		else {
			return -1;
			
		}
	}
}
