interface Colorable {
		void howToColor();
}