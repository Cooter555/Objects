public class Ex13_7 {
	public static void main(String[] args) {
		AbstractGeometricObject[] square = {new Square(6.9), new Square(11), new Square(42.0), new Square(8.1), new Square(21.0)};
		
		for (int i = 0; i < square.length; i++) {
			System.out.println("\nSquare " + (i + 1));
			System.out.println("Area:  " + square[i].getArea());
			((Square)square[i]).howToColor();
		}
	}
}